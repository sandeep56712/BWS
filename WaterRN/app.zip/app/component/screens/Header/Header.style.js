export default {
  headerView: { 
	  height:70,
	backgroundColor:'#013220',
	alignItems:'center',
	flexDirection:'row'
   },
	menuIcon:{
 	 resizeMode:'contain',
	  height:40,
	  width:20,
	 marginLeft:12,
	 marginTop:10,
	 tintColor:'black',
  },
	icon:{
 	 resizeMode:'contain',
	  height:30,
	  width:15,
	  marginTop:10,
	 //arginLeft:5
  },
	backIcon:{
 	 resizeMode:'contain',
	  height:15,
	  width:10,
	 // marginLeft:12,
	  //marginTop:10,
	 //arginLeft:5
  },
	textHeader:
	{
		color:'black',
		//marginLeft:'30%',
		fontSize:18,
		fontWeight:'bold',
		marginTop:10,
	},
  
};