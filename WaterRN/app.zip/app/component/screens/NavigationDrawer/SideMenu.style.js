export default {
  container: {
   flex:0,
	height: '100%'
  },
  navItemStyle: {
	 padding: 20,
    fontsize:20,
	  color:'black'
  },
  navSectionStyle: {
    backgroundColor: 'lightgrey',
	 
	  
  },
  sectionHeadingStyle: {
	   borderWidth:1,
	  borderRadius:0.5,
	  padding:5
	  
  },
	itemView:
	{
	  backgroundColor:'#D3D3D3',
		padding:15
	},
  
};