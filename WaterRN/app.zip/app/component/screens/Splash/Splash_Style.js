export default {
 container: {
     flex: 1,
    width: undefined,
    height: undefined,
   // backgroundColor:'transparent',
    justifyContent: 'center',
    alignItems: 'center',
   
  },
  imageView:{
    width:undefined,
    height:undefined,
    flex: 1,
    margin:10,
    resizeMode:'contain'
  }
};